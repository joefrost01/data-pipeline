# Surveillance Orchestrator Infrastructure

Terraform configuration for deploying the surveillance orchestrator to GCP.

**All BigQuery objects are Terraform-managed** - dbt inserts/merges into existing tables but does not create them.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              GCP Project                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐   │
│  │   Landing   │    │   Archive   │    │   Failed    │    │   Staging   │   │
│  │    (GCS)    │    │    (GCS)    │    │    (GCS)    │    │    (GCS)    │   │
│  └──────┬──────┘    └──────▲──────┘    └──────▲──────┘    └──────┬──────┘   │
│         │                  │                  │                  │          │
│         │                  │                  │                  │          │
│         ▼                  │                  │                  ▼          │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                         GKE Autopilot                                │   │
│  │  ┌────────────────────────────────────────────────────────────────┐  │   │
│  │  │                      Orchestrator Pod                          │  │   │
│  │  │  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐     │  │   │
│  │  │  │  Poll Files  │───▶│  Load to BQ  │───▶│   Run dbt    │     │  │   │
│  │  │  └──────────────┘    └──────────────┘    └──────────────┘     │  │   │
│  │  └────────────────────────────────────────────────────────────────┘  │   │
│  │                              │                                       │   │
│  │                   Workload Identity                                  │   │
│  └──────────────────────────────┼───────────────────────────────────────┘   │
│                                 │                                           │
│                                 ▼                                           │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                          BigQuery                                    │   │
│  │  ┌────────────────┐    ┌────────────────┐    ┌────────────────┐     │   │
│  │  │  raw_futures_  │───▶│  staging/stg_  │───▶│   marts/dim_   │     │   │
│  │  │  order_events  │    │  _order_events │    │   marts/fact_  │     │   │
│  │  └────────────────┘    └────────────────┘    └────────────────┘     │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Prerequisites

1. **GCP Project** with billing enabled
2. **gcloud CLI** installed and authenticated
3. **Terraform** >= 1.5.0
4. **kubectl** for cluster access

```bash
# Authenticate
gcloud auth application-default login

# Set project
gcloud config set project YOUR_PROJECT_ID
```

## Quick Start

```bash
# 1. Copy and edit variables
cp terraform.tfvars.example terraform.tfvars
vim terraform.tfvars

# 2. Initialise Terraform
terraform init

# 3. Preview changes
terraform plan

# 4. Apply
terraform apply
```

## Resources Created

| Resource | Purpose |
|----------|---------|
| **GCS: landing** | Incoming files from upstream |
| **GCS: archive** | Successfully processed files (lifecycle → Nearline → Coldline) |
| **GCS: failed** | Files that failed validation |
| **GCS: staging** | Temporary Parquet for BQ loading (1-day retention) |
| **BigQuery: datasets** | surveillance (raw), surveillance_staging, surveillance_marts |
| **BigQuery: raw tables** | load_metadata, raw_futures_order_events |
| **BigQuery: staging views** | stg_load_metadata, stg_futures_order_events |
| **BigQuery: intermediate views** | int_org_current, int_trader_current, int_account_current, int_instrument_current |
| **BigQuery: dimension tables** | dim_date, dim_time, dim_org, dim_trader, dim_account, dim_instrument, dim_order, dim_extra |
| **BigQuery: fact tables** | fact_futures_order_event (partitioned), fact_futures_order_event_current (view) |
| **GKE: Autopilot cluster** | Runs the orchestrator |
| **IAM: orchestrator SA** | Service account with Workload Identity |
| **IAM: dbt SA** | Separate SA for dbt (optional) |

## BigQuery Object Ownership

**Terraform creates and owns all BigQuery objects:**

- All datasets, tables, and views are defined in Terraform
- Schemas are enforced by Terraform
- dbt models should use `INSERT` / `MERGE` operations only
- Utility dimensions (dim_date, dim_time) are seeded on first apply
- dim_extra sentinel row (-1) is seeded on first apply

**dbt configuration for pre-existing tables:**

```yaml
# In dbt_project.yml
models:
  surveillance:
    marts:
      +materialized: incremental
      +full_refresh: false  # Never drop/recreate
      +on_schema_change: fail  # Alert if schema drifts
```

**For dimensions using SCD2 merge:**

```sql
-- dbt model should MERGE, not replace
{{ config(
    materialized='incremental',
    unique_key='<sk_column>',
    incremental_strategy='merge',
    full_refresh=false
) }}
```

## Post-Deployment

### Configure kubectl

```bash
# Get credentials (command from terraform output)
gcloud container clusters get-credentials orchestrator-cluster \
  --region europe-west2 \
  --project YOUR_PROJECT_ID

# Verify
kubectl get pods -n surveillance
```

### Build and Push Container

```bash
# Build
docker build -t gcr.io/YOUR_PROJECT/orchestrator:v1.0.0 .

# Push
docker push gcr.io/YOUR_PROJECT/orchestrator:v1.0.0

# Update deployment
kubectl set image deployment/orchestrator \
  orchestrator=gcr.io/YOUR_PROJECT/orchestrator:v1.0.0 \
  -n surveillance
```

### Upload Test File

```bash
# Copy a CSV to landing bucket
gsutil cp futures_order_events_20251215.csv gs://YOUR_PROJECT-surveillance-landing/

# Watch logs
kubectl logs -f deployment/orchestrator -n surveillance
```

## Customisation

### Add More Feeds

Edit the ConfigMap in `kubernetes.tf` or update via kubectl:

```bash
kubectl edit configmap orchestrator-table-config -n surveillance
```

### Scale Workers

```hcl
# In terraform.tfvars
orchestrator_workers = 8
orchestrator_memory  = "8Gi"
orchestrator_cpu     = "4000m"
```

### Use Existing VPC

Replace the network resources in `gke.tf` with data sources:

```hcl
data "google_compute_network" "existing" {
  name    = "your-existing-vpc"
  project = var.project_id
}
```

## Security Notes

1. **Workload Identity** - No service account keys, pods authenticate via GKE metadata
2. **Private Cluster** - Nodes have no public IPs, egress via Cloud NAT
3. **Least Privilege** - Orchestrator only has access to its specific buckets
4. **Deletion Protection** - Buckets and tables protected against accidental deletion

## Costs (Estimated)

| Resource | Approximate Monthly Cost |
|----------|-------------------------|
| GKE Autopilot | £50-100 (depends on pod resources) |
| BigQuery | Variable (storage + queries) |
| GCS | £5-20 (depends on volume) |
| Cloud NAT | £30 (fixed + egress) |

## Cleanup

```bash
# Remove Kubernetes resources first
kubectl delete namespace surveillance

# Then destroy infrastructure
terraform destroy
```

Note: Tables and buckets have deletion protection. Remove it first:

```hcl
# Temporarily set to allow deletion
deletion_protection = false
```
