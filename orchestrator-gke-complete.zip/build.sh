#!/bin/bash
# Build and push the orchestrator container image
set -e

# Configuration
PROJECT_ID="${GCP_PROJECT:-your-project-id}"
IMAGE_NAME="orchestrator"
REGION="${GCP_REGION:-europe-west2}"
REGISTRY="${REGISTRY:-gcr.io}"  # or europe-west2-docker.pkg.dev for Artifact Registry

# Version from git tag or commit
VERSION="${VERSION:-$(git describe --tags --always --dirty 2>/dev/null || echo 'latest')}"

FULL_IMAGE="${REGISTRY}/${PROJECT_ID}/${IMAGE_NAME}:${VERSION}"
LATEST_IMAGE="${REGISTRY}/${PROJECT_ID}/${IMAGE_NAME}:latest"

echo "Building: $FULL_IMAGE"

# Ensure we're authenticated
gcloud auth configure-docker "${REGISTRY%%/*}" --quiet 2>/dev/null || true

# Build
docker build \
    --platform linux/amd64 \
    -t "$FULL_IMAGE" \
    -t "$LATEST_IMAGE" \
    -f Dockerfile \
    .

echo ""
echo "Build complete. Images:"
echo "  $FULL_IMAGE"
echo "  $LATEST_IMAGE"
echo ""

# Push if requested
if [[ "${PUSH:-false}" == "true" ]]; then
    echo "Pushing images..."
    docker push "$FULL_IMAGE"
    docker push "$LATEST_IMAGE"
    echo ""
    echo "Pushed successfully."
    echo ""
    echo "To deploy to GKE:"
    echo "  kubectl set image deployment/orchestrator orchestrator=$FULL_IMAGE -n surveillance"
else
    echo "To push:"
    echo "  PUSH=true $0"
    echo ""
    echo "Or manually:"
    echo "  docker push $FULL_IMAGE"
    echo "  docker push $LATEST_IMAGE"
fi
