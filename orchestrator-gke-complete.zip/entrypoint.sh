#!/bin/bash
# Entrypoint script for Surveillance Orchestrator container
# Runs in GKE with BigQuery backend
set -e

echo "========================================"
echo "Surveillance Orchestrator Starting"
echo "========================================"
echo "Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo ""

# Validate required environment variables
REQUIRED_VARS=(
    "LANDING_PATH"
    "ARCHIVE_PATH"
    "FAILED_PATH"
    "TABLE_CONFIG_PATH"
    "GCP_PROJECT"
    "BQ_DATASET"
    "STAGING_BUCKET"
)

MISSING=()
for var in "${REQUIRED_VARS[@]}"; do
    if [[ -z "${!var}" ]]; then
        MISSING+=("$var")
    fi
done

if [[ ${#MISSING[@]} -gt 0 ]]; then
    echo "ERROR: Missing required environment variables:"
    for var in "${MISSING[@]}"; do
        echo "  - $var"
    done
    exit 1
fi

# Set defaults for optional variables
export LOADER_BACKEND="${LOADER_BACKEND:-bigquery}"
export LOADER_WORKERS="${LOADER_WORKERS:-4}"
export DBT_PROJECT_PATH="${DBT_PROJECT_PATH:-/app/dbt}"
export BQ_LOCATION="${BQ_LOCATION:-EU}"

# Print configuration
echo "Configuration:"
echo "  LANDING_PATH:     $LANDING_PATH"
echo "  ARCHIVE_PATH:     $ARCHIVE_PATH"
echo "  FAILED_PATH:      $FAILED_PATH"
echo "  TABLE_CONFIG_PATH: $TABLE_CONFIG_PATH"
echo "  GCP_PROJECT:      $GCP_PROJECT"
echo "  BQ_DATASET:       $BQ_DATASET"
echo "  BQ_LOCATION:      $BQ_LOCATION"
echo "  STAGING_BUCKET:   $STAGING_BUCKET"
echo "  LOADER_BACKEND:   $LOADER_BACKEND"
echo "  LOADER_WORKERS:   $LOADER_WORKERS"
echo "  DBT_PROJECT_PATH: $DBT_PROJECT_PATH"
echo ""

# Verify GCP authentication (Workload Identity should handle this)
echo "Verifying GCP authentication..."
if gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | head -1; then
    echo "  GCP authentication: OK (Workload Identity)"
else
    echo "  GCP authentication: Using Application Default Credentials"
fi
echo ""

# Verify BigQuery access
echo "Verifying BigQuery access..."
if bq show --project_id="$GCP_PROJECT" "$BQ_DATASET" >/dev/null 2>&1; then
    echo "  BigQuery dataset $GCP_PROJECT:$BQ_DATASET: OK"
else
    echo "  WARNING: Cannot access BigQuery dataset - may be created on first load"
fi
echo ""

# Verify GCS access
echo "Verifying GCS access..."
for bucket_path in "$LANDING_PATH" "$ARCHIVE_PATH" "$FAILED_PATH"; do
    bucket_name=$(echo "$bucket_path" | sed 's|gs://||' | cut -d'/' -f1)
    if gsutil ls "gs://$bucket_name" >/dev/null 2>&1; then
        echo "  $bucket_name: OK"
    else
        echo "  WARNING: Cannot access bucket $bucket_name"
    fi
done
echo ""

# Verify dbt is available
echo "Verifying dbt installation..."
if command -v dbt &> /dev/null; then
    echo "  dbt version: $(dbt --version | head -1)"
else
    echo "  ERROR: dbt not found"
    exit 1
fi
echo ""

# Verify dbt project exists
if [[ -f "$DBT_PROJECT_PATH/dbt_project.yml" ]]; then
    echo "  dbt project: $DBT_PROJECT_PATH (OK)"
else
    echo "  ERROR: dbt project not found at $DBT_PROJECT_PATH"
    exit 1
fi
echo ""

# Create dbt profiles.yml for BigQuery if it doesn't exist
DBT_PROFILES_DIR="${DBT_PROFILES_DIR:-$DBT_PROJECT_PATH}"
if [[ ! -f "$DBT_PROFILES_DIR/profiles.yml" ]]; then
    echo "Creating dbt profiles.yml for BigQuery..."
    cat > "$DBT_PROFILES_DIR/profiles.yml" << EOF
surveillance:
  target: prod
  outputs:
    prod:
      type: bigquery
      method: oauth
      project: ${GCP_PROJECT}
      dataset: ${BQ_DATASET}
      threads: 8
      timeout_seconds: 300
      location: ${BQ_LOCATION}
      priority: interactive
      retries: 3
EOF
    echo "  Created $DBT_PROFILES_DIR/profiles.yml"
fi
echo ""

# Install dbt dependencies if packages.yml exists
if [[ -f "$DBT_PROJECT_PATH/packages.yml" ]]; then
    echo "Installing dbt packages..."
    cd "$DBT_PROJECT_PATH"
    dbt deps --profiles-dir "$DBT_PROFILES_DIR" || true
    cd - > /dev/null
    echo ""
fi

# Test dbt connection
echo "Testing dbt BigQuery connection..."
cd "$DBT_PROJECT_PATH"
if dbt debug --profiles-dir "$DBT_PROFILES_DIR" 2>&1 | grep -q "All checks passed"; then
    echo "  dbt connection: OK"
else
    echo "  WARNING: dbt connection test had issues (may still work)"
fi
cd - > /dev/null
echo ""

echo "========================================"
echo "Starting Orchestrator"
echo "========================================"
echo ""

# Run the orchestrator
exec python -m orchestrator.main
